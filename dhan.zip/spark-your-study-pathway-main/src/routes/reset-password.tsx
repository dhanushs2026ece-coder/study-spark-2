import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { pageMeta } from "@/lib/page-meta";
import { Brand } from "@/components/brand";
export const Route = createFileRoute("/reset-password")({ head: () => pageMeta("Reset password | Subject Spark", "Set a new password for your Subject Spark account."), component: ResetPassword });
function ResetPassword() {
  const [recovery, setRecovery] = useState(false); const [message, setMessage] = useState(""); const [done, setDone] = useState(false); const [busy, setBusy] = useState(false);
  useEffect(() => { const hash = new URLSearchParams(window.location.hash.slice(1)); if (hash.get("type") === "recovery") setRecovery(true); }, []);
  async function submit(e: FormEvent<HTMLFormElement>) { e.preventDefault(); const f = new FormData(e.currentTarget); const password = String(f.get("password")); if (password !== f.get("confirm")) { setMessage("The passwords do not match."); return; } setBusy(true); const { error } = await supabase.auth.updateUser({ password }); setBusy(false); if (error) setMessage(error.message); else { setDone(true); setMessage("Your password has been updated."); } }
  return <main className="mx-auto max-w-md px-6 py-10"><Brand /><h1 className="mb-6 mt-12 text-3xl font-bold">New password</h1>{recovery && !done ? <form className="space-y-4" onSubmit={submit}><Label htmlFor="new-password">New password</Label><Input id="new-password" name="password" type="password" autoComplete="new-password" required minLength={8}/><Label htmlFor="confirm">Confirm password</Label><Input id="confirm" name="confirm" type="password" autoComplete="new-password" required minLength={8}/><Button disabled={busy} className="w-full">{busy ? "Saving…" : "Save password"}</Button></form> : !done && <p className="text-muted-foreground">Open the password reset link from your email to continue.</p>}{message && <p role="status" className="my-4">{message}</p>}<Button variant="link" asChild><Link to="/auth">Back to sign in</Link></Button></main>;
}