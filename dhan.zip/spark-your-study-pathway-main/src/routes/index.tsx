import { createFileRoute } from "@tanstack/react-router";
import { AccountEntry } from "@/components/account-entry";
import { pageMeta } from "@/lib/page-meta";
export const Route = createFileRoute("/")({ head: () => pageMeta("Subject Spark | Your Classroom", "Your classroom tasks and progress, together in Subject Spark."), component: AccountEntry });
