import { createFileRoute } from "@tanstack/react-router";
import { ClassroomPage } from "@/components/classroom-page";
import { classroomQuery } from "@/lib/classroom.functions";
import { pageMeta } from "@/lib/page-meta";
export const Route = createFileRoute("/_authenticated/classroom")({ loader: ({ context }) => context.queryClient.ensureQueryData(classroomQuery()), head: () => pageMeta("Classroom tasks | Subject Spark", "Your classroom assignments and saved progress in Subject Spark."), component: ClassroomPage });