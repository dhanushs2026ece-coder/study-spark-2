import { createFileRoute } from "@tanstack/react-router";
import { AccountEntry } from "@/components/account-entry";
import { pageMeta } from "@/lib/page-meta";
export const Route = createFileRoute("/auth")({ head: () => pageMeta("Sign in | Subject Spark", "Sign in to your Subject Spark classroom."), component: AccountEntry });