import { Link } from "@tanstack/react-router";
export function Brand() {
  return <Link to="/" className="flex items-center gap-3"><img src="/favicon.png?v=2" alt="" className="h-10 w-10 rounded-md object-contain" /><span className="text-lg font-extrabold">Subject Spark<span className="block text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Classroom</span></span></Link>;
}