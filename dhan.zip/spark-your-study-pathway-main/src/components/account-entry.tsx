import { useEffect, useState, type FormEvent } from "react";
import { useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import "@lovable.dev/cloud-auth-js/styles.css";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Brand } from "./brand";
import { ArrowRight, CheckCircle2, GraduationCap } from "lucide-react";

export function AccountEntry() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup" | "forgot">("signin");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  useEffect(() => { let active = true; void supabase.auth.getUser().then(({ data }) => { if (active && data.user) void navigate({ to: "/classroom", replace: true }); }); return () => { active = false; }; }, [navigate]);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    const fields = new FormData(event.currentTarget);
    const email = String(fields.get("email")); const password = String(fields.get("password") ?? "");
    try {
      if (mode === "forgot") {
        const result = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` });
        if (result.error) throw result.error;
        setMessage("Check your email for a password reset link.");
      } else if (mode === "signup") {
        const result = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin, data: { display_name: String(fields.get("name")).trim() } } });
        if (result.error) throw result.error;
        if (result.data.session) await navigate({ to: "/classroom" });
        else setMessage("Check your email to confirm your account. Then sign in here.");
      } else {
        const result = await supabase.auth.signInWithPassword({ email, password });
        if (result.error) throw result.error;
        await navigate({ to: "/classroom" });
      }
    } catch (e) { setError(e instanceof Error ? e.message : "Something went wrong. Please try again."); }
    finally { setBusy(false); }
  }
  async function social(provider: "google" | "lovable") {
    setError(""); setBusy(true);
    try { const result = await lovable.auth.signInWithOAuth(provider, { redirect_uri: window.location.origin }); if (result.error) { setError(result.error.message); return; } if (!result.redirected) await navigate({ to: "/classroom" }); }
    catch { setError("Sign-in did not finish. Please try again."); } finally { setBusy(false); }
  }
  return <div className="min-h-screen"><header className="border-b bg-card px-6 py-5"><div className="mx-auto flex max-w-6xl items-center justify-between"><Brand /><span className="hidden text-sm text-muted-foreground sm:block">A little progress, every day.</span></div></header>
    <main className="mx-auto max-w-6xl px-6 py-12 sm:py-16"><div className="mb-10 flex items-center gap-2 text-sm font-semibold text-primary"><GraduationCap className="h-5 w-5" /> YOUR CLASSROOM, TOGETHER</div><h1 className="max-w-2xl text-4xl font-extrabold leading-tight sm:text-5xl">Subject Spark<br /><span className="text-primary">Small tasks. Big progress.</span></h1>
      <div className="mt-10 grid gap-12 lg:grid-cols-[1fr_420px]"><div className="space-y-7"><p className="max-w-md text-lg leading-relaxed text-muted-foreground">A fresh start for your next classroom task.</p><div className="flex items-center gap-4 border-y py-6"><span className="flex h-12 w-12 items-center justify-center rounded-full bg-highlight"><CheckCircle2 className="h-6 w-6" /></span><span className="font-semibold">One task at a time.<br /><span className="text-sm font-normal text-muted-foreground">You’ve got this.</span></span></div></div>
        <section className="rounded-lg border bg-card p-6 sm:p-8"><h2 className="text-2xl font-bold">{mode === "signup" ? "Create your account" : mode === "forgot" ? "Reset your password" : "Welcome back"}</h2><p className="mb-6 mt-2 text-sm text-muted-foreground">{mode === "signup" ? "Your next chapter starts here." : mode === "forgot" ? "Let’s get you back to class." : "Ready for a little progress?"}</p>
          <form onSubmit={submit} className="space-y-4">{mode === "signup" && <div className="space-y-2"><Label htmlFor="name">Your name</Label><Input id="name" name="name" autoComplete="name" placeholder="Your full name" required maxLength={80} /></div>}<div className="space-y-2"><Label htmlFor="email">Email</Label><Input id="email" name="email" type="email" autoComplete="email" placeholder="you@example.com" required /></div>{mode !== "forgot" && <div className="space-y-2"><Label htmlFor="password">Password</Label><Input id="password" name="password" type="password" autoComplete={mode === "signup" ? "new-password" : "current-password"} required minLength={8} /></div>}
            {error && <p role="alert" className="text-sm text-destructive">{error}</p>}{message && <p role="status" className="rounded-md bg-success-soft p-3 text-sm text-success">{message}</p>}<Button className="h-11 w-full" disabled={busy}>{busy ? "Please wait…" : mode === "signup" ? "Create account" : mode === "forgot" ? "Send reset link" : "Sign in"}<ArrowRight /></Button>
          </form>{mode !== "forgot" && <><div className="my-5 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />OR<span className="h-px flex-1 bg-border" /></div><div className="space-y-3"><Button variant="outline" className="google-auth h-11 w-full" disabled={busy} onClick={() => social("google")}><svg aria-hidden="true" viewBox="0 0 24 24" className="h-[18px] w-[18px]"><path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"/><path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"/><path fill="#FBBC05" d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"/><path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"/></svg>Continue with Google</Button><Button className="lovable-auth-button w-full" disabled={busy} onClick={() => social("lovable")}>Continue with Lovable</Button></div></>}
          <div className="mt-5 flex flex-wrap justify-center gap-1"><Button variant="link" size="sm" onClick={() => { setMode(mode === "signin" ? "signup" : "signin"); setError(""); setMessage(""); }}>{mode === "signin" ? "Create an account" : "Back to sign in"}</Button>{mode === "signin" && <Button variant="link" size="sm" onClick={() => { setMode("forgot"); setError(""); setMessage(""); }}>Forgot password?</Button>}</div>
        </section></div></main></div>;
}