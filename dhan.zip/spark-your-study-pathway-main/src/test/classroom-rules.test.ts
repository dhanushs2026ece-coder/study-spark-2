import { describe, it, expect } from "vitest";
import { canPostTask, canCompleteTask, taskSchema } from "@/lib/classroom-rules";
describe("Classroom task permissions", () => {
  it("lets the classroom teacher post a task", () => { expect(canPostTask("teacher-a", "teacher-a", ["teacher"])).toBe(true); });
  it("does not let a student post a task", () => { expect(canPostTask("student-a", "teacher-a", ["student"])).toBe(false); });
  it("does not let another teacher post to this classroom", () => { expect(canPostTask("teacher-b", "teacher-a", ["teacher"])).toBe(false); });
  it("lets a student complete a task", () => { expect(canCompleteTask("student-a", "teacher-a", ["student"])).toBe(true); });
  it("does not let a teacher mark their own task completed", () => { expect(canCompleteTask("teacher-a", "teacher-a", ["student", "teacher"])).toBe(false); });
  it("requires a task title", () => { expect(taskSchema.safeParse({ classroom_id: "11111111-1111-4111-8111-111111111111", title: " ", instructions: "", subject: "Science", due_date: null }).success).toBe(false); });
});