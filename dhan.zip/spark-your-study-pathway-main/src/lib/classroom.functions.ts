import { createServerFn } from "@tanstack/react-start";
import { queryOptions } from "@tanstack/react-query";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { taskSchema, canPostTask, canCompleteTask } from "./classroom-rules";

export const getClassroom = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(async ({ context: { supabase, userId } }) => {
  const [profile, roles, rooms] = await Promise.all([
    supabase.from("profiles").select("display_name").eq("id", userId).single(),
    supabase.from("user_roles").select("role").eq("user_id", userId),
    supabase.from("classrooms").select("*").order("created_at", { ascending: false }),
  ]);
  if (profile.error || roles.error || rooms.error) throw new Error("Your classroom could not be loaded. Please try again.");
  const ids = (rooms.data ?? []).map(r => r.id);
  if (!ids.length) return { userId, name: profile.data.display_name, roles: (roles.data ?? []).map(r => r.role), rooms: [], tasks: [], completions: [], members: [] };
  const [tasks, members] = await Promise.all([
    supabase.from("tasks").select("*").in("classroom_id", ids).order("created_at", { ascending: false }),
    supabase.from("classroom_members").select("classroom_id,user_id,profiles(display_name)").in("classroom_id", ids),
  ]);
  if (tasks.error || members.error) throw new Error("Your tasks could not be loaded. Please try again.");
  const taskIds = tasks.data.map(t => t.id);
  const completions = taskIds.length ? await supabase.from("task_completions").select("*").in("task_id", taskIds) : { data: [], error: null };
  if (completions.error) throw new Error("Your progress could not be loaded. Please try again.");
  return { userId, name: profile.data.display_name, roles: roles.data.map(r => r.role), rooms: rooms.data, tasks: tasks.data, completions: completions.data ?? [], members: members.data };
});
export const classroomQuery = () => queryOptions({ queryKey: ["classroom"], queryFn: () => getClassroom(), staleTime: 0 });

export const enterClassroom = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ mode: z.enum(["create", "join"]), value: z.string().trim().min(1).max(80) }).parse(data))
  .handler(async ({ data, context }) => {
    const result = data.mode === "create" ? await context.supabase.rpc("create_classroom", { room_name: data.value }) : await context.supabase.rpc("join_classroom", { code: data.value });
    if (result.error) throw new Error(data.mode === "join" ? "That classroom code was not found. Check it and try again." : "Your classroom could not be created. Please try again.");
    return result.data;
  });
export const postTask = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data: unknown) => taskSchema.parse(data))
  .handler(async ({ data, context }) => {
    const [room, roles] = await Promise.all([context.supabase.from("classrooms").select("teacher_id").eq("id", data.classroom_id).single(), context.supabase.from("user_roles").select("role").eq("user_id", context.userId)]);
    if (!room.data || !canPostTask(context.userId, room.data.teacher_id, (roles.data ?? []).map(r => r.role))) throw new Error("Only this classroom's teacher can post tasks.");
    const result = await context.supabase.from("tasks").insert(data).select("id").single();
    if (result.error) throw new Error("Your task was not saved. Please try again.");
    return result.data;
  });
export const completeTask = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data: unknown) => z.object({ taskId: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const task = await context.supabase.from("tasks").select("classroom_id").eq("id", data.taskId).single();
    if (!task.data) throw new Error("This task is not available in your classroom.");
    const [room, roles] = await Promise.all([context.supabase.from("classrooms").select("teacher_id").eq("id", task.data.classroom_id).single(), context.supabase.from("user_roles").select("role").eq("user_id", context.userId)]);
    if (!room.data || !canCompleteTask(context.userId, room.data.teacher_id, (roles.data ?? []).map(r => r.role))) throw new Error("Only students in this classroom can complete tasks.");
    const existing = await context.supabase.from("task_completions").select("completed_at").eq("task_id", data.taskId).eq("student_id", context.userId).maybeSingle();
    if (existing.data) return existing.data;
    const result = await context.supabase.from("task_completions").insert({ task_id: data.taskId, student_id: context.userId }).select("completed_at").single();
    if (result.error) throw new Error("Your completion was not saved. Please try again.");
    return result.data;
  });