import { z } from "zod";

export const taskSchema = z.object({
  classroom_id: z.string().uuid(),
  title: z.string().trim().min(1).max(120),
  instructions: z.string().trim().max(2000),
  subject: z.string().trim().min(1).max(60),
  due_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable(),
});
export function canPostTask(userId: string, teacherId: string, roles: string[]) {
  return userId === teacherId && roles.includes("teacher");
}
export function canCompleteTask(userId: string, teacherId: string, roles: string[]) {
  return userId !== teacherId && roles.includes("student");
}